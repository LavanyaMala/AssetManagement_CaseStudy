package com.java.myexceptions;

public class AssetNotFoundException extends Exception {
    public AssetNotFoundException(String message) {
        super(message);
    }
    
}
